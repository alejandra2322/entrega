from django.conf.urls import include
from django.urls import path
from django.contrib import admin

urlpatterns = [
    path(r'^polls/', include('polls.urls', namespace="polls")),
    path(r'^admin/', include(admin.site.urls)),
]