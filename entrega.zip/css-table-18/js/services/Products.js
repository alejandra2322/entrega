async function getProducts(url) {
    const products = fetch(url)
        .then(response=>response.json())
        .then(products=>{
            let p = products.products

            p = p.map(product=>{
                product.price = product.price.replace('.', '')
                product.price = parseFloat(product.price)
                return product
            })
            return p
        })

    return products
}

async function getCategories(url) {
    const categories = fetch(url)
        .then(response=>response.json())
        .then(categories=>categories.categories)

    return categories
}

export {
    getProducts,
    getCategories
}