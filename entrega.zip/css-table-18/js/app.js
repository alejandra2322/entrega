import { getProducts, getCategories } from "./services/Products.js"

const url_base = `${window.location}/src/products.json`
const table = document.querySelector("#tableProducts tbody")
const select = document.querySelector("#category")
const state = document.querySelector("#state")
const product_input = document.querySelector("#product")
const sorted_input = document.querySelector("#sort_products")

async function loadData(){

    const products = await getProducts(url_base)
    const categories = await getCategories(url_base)
    const category = convertCategories(categories)

    //Llena el select para filtrar los productos por categoría
    categories.forEach(category=>{
        select.innerHTML += `<option value="${category.categori_id}">${category.name}</option>`
    })
    
    showProducts(products, category)
}

function convertCategories(categories) {
    //Convierte el arreglo en un único objeto para mostrar los nombres de categoría
    const category = {}
    categories.map(categorie=>{
        category[categorie.categori_id] = categorie.name
        return category
    })

    return category
}

function showProducts(products, category) {
    table.innerHTML = ''
    //Imprime los productos
    products.forEach(product => {
        product.categories = product.categories.map(categorie=>{
            return category[categorie]
        })
        product.categories = product.categories.join()
        const row = `<tr scope="row">
            <th scope="row">
                <label class="control control--checkbox">
                    <input type="checkbox"/>
                    <div class="control__indicator"></div>
                </label>
            </th>
            <td>
                ${product.name}
            </td>
            <td><a href="#">${product.price}</a></td>
            <td>
                ${product.description}
                <small class="d-block">${product.categories}</small>
            </td>
            <td>${product.categories}</td>
            <td>
                <label class="control control--checkbox">
                    <input type="checkbox" ${product.available ? 'checked' : ''} disabled/>
                    <div class="control__indicator"></div>
                </label>
            </td>
            <td>
                <label class="control control--checkbox">
                    <input type="checkbox" ${product.best_seller ? 'checked' : ''} disabled/>
                    <div class="control__indicator"></div>
                </label>
            </td>
        </tr>
        <tr class="spacer"><td colspan="100"></td></tr>`

        table.innerHTML += row
    })
}

select.addEventListener('change', async function(e){
    const category_select = e.target.value
    const products = await getProducts(url_base)
    const categories = await getCategories(url_base)
    const category = convertCategories(categories)

    if(category_select){
        const products_filtered = filterProductsByCategory(products, category_select)
        console.log(products_filtered)
        showProducts(products_filtered, category)
    }else{
        showProducts(products, category)
    }
})

state.addEventListener('change', async function(e){
    const state_select = e.target.value
    const products = await getProducts(url_base)
    const categories = await getCategories(url_base)
    const category = convertCategories(categories)

    if(state_select)
    {
        const products_filtered = filterProductsByState(products, state_select)
        console.log(products_filtered)
        showProducts(products_filtered, category)
    }else{
        showProducts(products, category)
    }
})

product_input.addEventListener('change', async function(e){
    const product_input_value = e.target.value
    const products = await getProducts(url_base)
    const categories = await getCategories(url_base)
    const category = convertCategories(categories)

    if(product_input_value){
        const products_filtered = products.filter(product=>{
            return product.name.toLowerCase().includes(product_input_value.toLowerCase())
        })
        showProducts(products_filtered, category)
    }
})

sorted_input.addEventListener('change', async function(e){
    const sorted_input_value = e.target.value
    const products = await getProducts(url_base)
    const categories = await getCategories(url_base)
    const category = convertCategories(categories)

    let type_sort = 'asc'
    let sort_value = null

    if(sorted_input_value){
        sort_value = sorted_input_value === 'name' ? 'name' : 'price'

        if(sort_value === 'price'){
            type_sort = sorted_input_value === 'min_price' ? 'asc' : 'desc'
        }

        console.log(sort_value, type_sort)
        const products_sorted = sortedProducts(products, sort_value, type_sort)
        showProducts(products_sorted, category)
    }
})

function filterProductsByCategory(products, category){
    const productsFiltered = products.filter(product=>{
        return product.categories.includes(parseInt(category))
      })
    return productsFiltered
}

function filterProductsByState(products, state_filter){
    const products_filtered = products.filter(product=>{
        if(state_filter === 'available'){
            return product.available
        }else if(state_filter === 'not_available'){
            return !product.available
        }else{
            return product.best_seller
        }
    })
    return products_filtered
}

function sortedProducts(products, value_sort, type_sort){
    const products_sorted = products.sort((a, b) => {
        if(value_sort === 'price'){
            if(type_sort === 'asc'){
                console.log(type_sort)
                return (a.price) - (b.price);
            }else{
                return (b.price) - (a.price);
            }
        }else{
            let fa = a[value_sort].toLowerCase(),
                fb = b[value_sort].toLowerCase();
            
            if (fa < fb) {
                return -1;
            }
            if (fa > fb) {
                return 1;
            }
            return 0;
        }
    });

    return products_sorted
}

loadData()